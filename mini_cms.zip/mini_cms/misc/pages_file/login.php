<?php
header("Location: login/");
?>